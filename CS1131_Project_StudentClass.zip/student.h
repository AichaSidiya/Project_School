#include <string>
class student
{
    private:
      //attributes
      string number;
      string name;
      string majorPgm;
      float gpa;

    public:
      //methods
      student(); //defult constructor
      student(string id, string n, string major, float g); //overloading constructor
      // setters and getters
      void setID(string id);
      string getID();
      void setName(srting n);
      string getName();
      void setMajor(string major);
      string getMajor();
      void setGPA(float g);
      float getGPA();
      bool lessThan(student&);
      void print();

}
