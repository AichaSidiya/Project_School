#include <iostream>
#include <string>
#include "student.h"
using namespace std;
//functions' definition
student::student(){//initialize
    number="";
    name="";
    majorPgm="";
    gpa=0.0;
}
student::student(string id, string n, string major, float g){
    number=id;
    name=n;
    majorPgm=major;
    gpa=g;
}
void student::setID(string id){ //set the ID number
    number=id;
}
string student::getID(){ //get the ID number
    return number;
}
void student::setName(srting n){ //set the name of the student
    name=n;
}
string student::getName(){ //get the name of the student
    return name;
}
void student::setMajor(string major){ //set the major of the student
    majorPgm=major;
}
string student::getMajor(){ //get the major of the student
    return majorPgm;
}
void student::setGPA(float g){ //set the GPA of the student
    gpa=g;
}
float student::getGPA(){ //get the GPA of the student
    return gpa;
}
bool student::lessThan(const student& otherStudent){ //comparing two objects
    return name < otherStudent.name;
}
void student::print(){ //print the data of the object
    cout << "Student's number: " << number << endl;
    cout << "Student's name: " << name << endl;
    cout << "Student's major: " << majorPgm << endl;
    cout << "Student's GPA: " << gpa << endl;
}
